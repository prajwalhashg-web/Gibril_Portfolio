import { useMemo } from 'react';
import { nav } from './data/candidate';
import { useActiveSection } from './hooks/useActiveSection';
import { useReveal } from './hooks/useReveal';
import { useTableRoles } from './hooks/useTableRoles';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ProfessionalIntro } from './components/ProfessionalIntro';
import { ExperienceTimeline } from './components/ExperienceTimeline';
import { Marquee } from './components/Marquee';
import { StrengthsGrid } from './components/StrengthsGrid';
import { TransferableSkills } from './components/TransferableSkills';
import { CareerDirection } from './components/CareerDirection';
import { QualificationsSection } from './components/QualificationsSection';
import { LanguagesSection } from './components/LanguagesSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export default function App() {
  // Strengths also covers the transfer table that follows it.
  const ids = useMemo(() => ['about', 'experience', 'strengths', 'transfer', 'direction', 'qualifications', 'contact'], []);
  const raw = useActiveSection(ids);
  const active = raw === 'transfer' ? 'strengths' : raw === 'qualifications' ? 'direction' : raw;
  useReveal();
  useTableRoles();

  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <Navbar active={nav.some((n) => n.id === active) ? active : ''} />
      <main id="main">
        <HeroSection />
        <ProfessionalIntro />
        <ExperienceTimeline />
        <Marquee />
        <StrengthsGrid />
        <TransferableSkills />
        <CareerDirection />
        <QualificationsSection />
        <LanguagesSection />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}
