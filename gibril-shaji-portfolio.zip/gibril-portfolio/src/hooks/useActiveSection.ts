import { useEffect, useState } from 'react';

/** Tracks which section is in the reading zone, using IntersectionObserver (no scroll listeners). */
export function useActiveSection(ids: string[]): string {
  const [active, setActive] = useState('');

  useEffect(() => {
    const els = ids
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => el !== null);
    if (!els.length || !('IntersectionObserver' in window)) return;

    const visible = new Map<string, number>();
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) visible.set(e.target.id, e.intersectionRatio);
          else visible.delete(e.target.id);
        }
        // The first section (in page order) that sits in the reading zone wins.
        const current = ids.find((id) => visible.has(id)) ?? '';
        setActive(current);
      },
      { rootMargin: '-35% 0px -55% 0px', threshold: [0, 0.01] },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [ids]);

  return active;
}
