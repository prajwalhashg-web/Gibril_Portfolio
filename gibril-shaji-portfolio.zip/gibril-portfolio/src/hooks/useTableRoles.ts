import { useEffect } from 'react';

/**
 * On phones the tables are restyled as stacked blocks (display: block),
 * which makes some browsers drop table semantics. Explicit ARIA roles keep
 * screen readers announcing rows, headers and cells at every width.
 */
export function useTableRoles(): void {
  useEffect(() => {
    document.querySelectorAll('.tbl table').forEach((t) => {
      t.setAttribute('role', 'table');
      t.querySelectorAll('thead, tbody').forEach((g) => g.setAttribute('role', 'rowgroup'));
      t.querySelectorAll('tr').forEach((r) => r.setAttribute('role', 'row'));
      t.querySelectorAll('thead th').forEach((h) => h.setAttribute('role', 'columnheader'));
      t.querySelectorAll('tbody th').forEach((h) => h.setAttribute('role', 'rowheader'));
      t.querySelectorAll('td').forEach((d) => d.setAttribute('role', 'cell'));
    });
  }, []);
}
