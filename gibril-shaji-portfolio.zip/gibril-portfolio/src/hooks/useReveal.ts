import { useEffect } from 'react';

/**
 * Staggered entrance for elements marked data-reveal (set --i for order).
 * Content stays visible if JS fails or motion is reduced: the hidden state only
 * applies once this hook adds `reveal-armed` to <html>.
 */
export function useReveal(): void {
  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce || !('IntersectionObserver' in window)) return;

    const root = document.documentElement;
    const els = Array.from(document.querySelectorAll<HTMLElement>('[data-reveal]'));

    // Anything already on screen at load is shown immediately, so the first frame is complete.
    const vh = window.innerHeight;
    els.forEach((el) => {
      if (el.getBoundingClientRect().top < vh) el.classList.add('is-in');
    });
    root.classList.add('reveal-armed');

    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add('is-in');
            io.unobserve(e.target);
          }
        }
      },
      { rootMargin: '0px 0px -8% 0px', threshold: 0.05 },
    );
    els.filter((el) => !el.classList.contains('is-in')).forEach((el) => io.observe(el));

    const showAll = () => els.forEach((el) => el.classList.add('is-in'));
    window.addEventListener('beforeprint', showAll);
    return () => {
      io.disconnect();
      window.removeEventListener('beforeprint', showAll);
    };
  }, []);
}
