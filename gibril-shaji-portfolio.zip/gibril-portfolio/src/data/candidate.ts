/**
 * All candidate content lives here. Edit this file to update the site;
 * no layout code needs to change.
 *
 * Source of truth: Gibril Shaji's original CV (2026). Nothing here may claim
 * real estate employment, transactions, licences, revenue or testimonials.
 */

export type NavItem = { id: string; label: string };

export type Role = {
  title: string;
  company: string;
  location: string;
  start: string;
  end: string;
  points: string[];
};

export type Strength = {
  icon: 'consult' | 'qualify' | 'present' | 'docs' | 'communicate' | 'solve';
  title: string;
  text: string;
};

export type ValueRow = { strength: string; evidence: string; potential: string };
export type TransferRow = { experience: string; demonstrates: string; application: string; benefit: string };
export type SkillRow = { skill: string; relevance: string };
export type AreaRow = { id: string; area: string; strength: string; contribution: string; focus: string };

export const candidate = {
  name: 'Gibril Shaji',
  firstName: 'Gibril',
  headline: 'Sales Professional | Aspiring Dubai Real Estate Consultant',
  location: 'Dubai, United Arab Emirates',
  locationShort: 'Dubai, UAE',
  phone: '+971 561697873',
  phoneHref: 'tel:+971561697873',
  email: 'gibrilshajifcc@gmail.com',
  linkedin: 'https://linkedin.com/in/gibril-shaji',
  linkedinLabel: 'linkedin.com/in/gibril-shaji',

  /** Resume served from /public. Replace the file to update it; keep the path or edit it here. */
  resume: {
    href: 'resume/Gibril_Shaji_Resume.pdf',
    fileName: 'Gibril_Shaji_Resume.pdf',
  },

  /**
   * Optional verified headshot. Leave null until a real photograph of Gibril is supplied.
   * Example: { src: '/images/gibril-shaji.jpg', alt: 'Gibril Shaji' }
   */
  portrait: null as null | { src: string; alt: string },

  hero: {
    statement: 'Sales Experience. A New Direction in Real Estate.',
    support:
      'Client-focused sales professional with experience in Dubai and India, bringing consultative selling and lead qualification to property sales.',
    tagline: 'Client relationships. Consultative selling. A customer-first approach to property.',
  },

  /** Short, verifiable facts used in the hero rail and the intro. */
  facts: ['Based in Dubai, UAE', 'Working since 2018', 'Selling at GCC Gamers', 'Four languages'],

  intro: {
    heading: 'Built on Sales. Focused on People.',
    lead:
      'Gibril Shaji works in consultative technical sales in Dubai. He helps customers work out what they actually need, then explains the options plainly so they can choose with confidence.',
    body:
      'Before Dubai, he ran software demonstrations, handled client inquiries and prepared quotations for clients in Bengaluru, after starting out in IT support. He is now bringing that customer-first way of working to a new career in Dubai property sales.',
    approach: [
      'Understand requirements before recommending solutions.',
      'Explain options in a clear and practical way.',
      'Help customers assess suitability.',
      'Manage inquiries and qualify leads.',
      'Support customers with product information and documentation.',
    ],
  },

  strengths: [
    { icon: 'consult', title: 'Consultative Selling', text: 'Understanding customer requirements and recommending relevant solutions.' },
    { icon: 'qualify', title: 'Lead Qualification', text: 'Experience handling client inquiries and assessing customer needs.' },
    { icon: 'present', title: 'Product Presentation', text: 'Explaining product capabilities and presenting options clearly.' },
    { icon: 'docs', title: 'Sales Documentation', text: 'Experience preparing quotations, proposals, and estimates.' },
    { icon: 'communicate', title: 'Customer Communication', text: 'Helping customers understand options and make informed decisions.' },
    { icon: 'solve', title: 'Problem-Solving', text: 'Technical support experience involving troubleshooting and customer assistance.' },
  ] satisfies Strength[],

  roles: [
    {
      title: 'System Sales Officer',
      company: 'GCC Gamers',
      location: 'Dubai, UAE',
      start: 'Feb 2025',
      end: 'Present',
      points: [
        'Provide technical consultation to customers planning custom PC and server builds.',
        'Support customers with hardware selection, explaining options clearly.',
        'Help customers assess product suitability and performance requirements.',
      ],
    },
    {
      title: 'Technical Sales Engineer',
      company: 'Cadvin Technologies Pvt. Ltd.',
      location: 'Bengaluru, India',
      start: 'Mar 2024',
      end: 'Sep 2024',
      points: [
        'Conducted software demonstrations and provided technical support to clients.',
        'Managed client inquiries and qualified leads.',
      ],
    },
    {
      title: 'Technical Sales Engineer',
      company: 'Rayotech Ecosystems & Solutions Pvt. Ltd.',
      location: 'Bengaluru, India',
      start: 'Oct 2022',
      end: 'Oct 2023',
      points: [
        'Prepared quotations, proposals, and estimates for clients.',
        'Trained junior team members on product features.',
      ],
    },
    {
      title: 'IT Technical Support',
      company: 'Bethany Medical Centre',
      location: 'Coimbatore, India',
      start: 'Jul 2018',
      end: 'Jun 2019',
      points: [
        'Provided IT support for systems, AV equipment, and network setups.',
        'Performed troubleshooting and system maintenance.',
      ],
    },
  ] satisfies Role[],

  /** Table 1: What I Bring to a Real Estate Sales Team */
  value: [
    { strength: 'Consultative Selling', evidence: 'At GCC Gamers, I help customers identify suitable PC and server configurations based on their requirements.', potential: "Understand a buyer's or tenant's needs before presenting relevant properties." },
    { strength: 'Lead Qualification', evidence: 'At Cadvin Technologies, I managed client inquiries and qualified leads.', potential: 'Identify genuine property requirements, budgets, preferred locations, and timelines through structured discovery.' },
    { strength: 'Clear Product Presentation', evidence: 'I have demonstrated software and explained technical product features in customer-friendly terms.', potential: 'Communicate property features, amenities, project information, and relevant differences clearly.' },
    { strength: 'Customer Decision Support', evidence: 'I guide customers through available hardware options and suitability considerations.', potential: 'Help prospective clients compare verified property options and understand their differences.' },
    { strength: 'Sales Documentation', evidence: 'At Rayotech Ecosystems & Solutions, I prepared quotations, proposals, and estimates.', potential: 'Support clear communication of property prices, documented offers, and associated costs under brokerage procedures.' },
    { strength: 'Problem-Solving', evidence: 'My IT technical support background includes troubleshooting systems and assisting users.', potential: 'Respond constructively to client questions and coordinate solutions with the relevant team.' },
  ] satisfies ValueRow[],

  /** Table 2: Experience That Transfers to Property Sales */
  transfer: [
    { experience: 'Customer consultation for custom PC/server builds', demonstrates: 'Requirement discovery and solution matching', application: "Understand the client's property preferences and intended use.", benefit: 'More relevant property recommendations.' },
    { experience: 'Lead qualification at Cadvin Technologies', demonstrates: 'Initial inquiry handling and assessment of requirements', application: 'Structure buyer, tenant, or investor discovery conversations.', benefit: 'Less time spent on unsuitable options.' },
    { experience: 'Software demonstrations', demonstrates: 'Explaining features and answering customer questions', application: 'Present property features and verified project information.', benefit: 'Better understanding of available options.' },
    { experience: 'Quotations, proposals, and estimates', demonstrates: 'Clear presentation of pricing and solution details', application: 'Help explain documented pricing and costs under brokerage guidance.', benefit: 'Greater clarity throughout the sales process.' },
    { experience: 'Technical support and troubleshooting', demonstrates: 'Practical problem-solving and customer assistance', application: 'Coordinate responses to questions and practical concerns.', benefit: 'A more professional customer experience.' },
  ] satisfies TransferRow[],

  /** Table 3: Skills I Can Bring to the Role */
  skills: [
    { skill: 'Consultative Sales', relevance: 'Discover requirements and present suitable solutions.' },
    { skill: 'Client Requirement Analysis', relevance: 'Clarify priorities before recommending options.' },
    { skill: 'Lead Qualification', relevance: 'Assess whether an inquiry matches the offering and next steps.' },
    { skill: 'Product Demonstrations', relevance: 'Explain features and benefits clearly.' },
    { skill: 'Sales Proposals & Quotations', relevance: 'Communicate documented information and pricing accurately.' },
    { skill: 'Customer Communication', relevance: 'Maintain clear, professional client interactions.' },
    { skill: 'Problem-Solving', relevance: 'Respond constructively to questions and coordinate assistance.' },
    { skill: 'Team Collaboration', relevance: 'Work with colleagues and follow established processes.' },
  ] satisfies SkillRow[],

  /** Table 4: Where I Aim to Apply My Sales Experience (career interests, not specialisations) */
  areas: [
    { id: 'residential', area: 'Residential Sales & Rentals', strength: 'Requirement discovery and customer consultation', contribution: 'Understand client preferences and help identify relevant options.', focus: 'Buyer and tenant requirements, property comparisons, and customer follow-up.' },
    { id: 'offplan', area: 'Off-Plan & Developer Sales', strength: 'Product presentation and explaining features', contribution: 'Learn project details and communicate verified information clearly.', focus: 'Learning project information, understanding customer needs, and supporting project presentations.' },
    { id: 'investor', area: 'Investor-Focused Property Sales', strength: 'Structured comparison and clear communication', contribution: 'Help clients review property information and compare options without making unsupported investment promises.', focus: 'Communicating verified property information and helping customers compare options under appropriate brokerage guidance.' },
    { id: 'commercial', area: 'Commercial Real Estate', strength: 'Lead qualification and requirement analysis', contribution: 'Understand business-property needs and support relevant client inquiries.', focus: 'Understanding business-property requirements and communicating relevant options.' },
  ] satisfies AreaRow[],

  education: 'B.Tech in Electronics & Communication',
  certifications: [
    { name: 'SolidCAM Certified Sales Associate', issuer: '' },
    { name: 'IT Support for Hybrid Workforce', issuer: 'LinkedIn' },
    { name: 'Data Analytics', issuer: 'Simplilearn' },
  ],
  tools: ['Microsoft Office', 'Advanced Excel', 'Power BI', 'Tableau', 'SolidWorks', 'SolidCAM'],
  languages: ['English', 'Malayalam', 'Tamil', 'Kannada'],

  contact: {
    heading: "Let's Start a Conversation.",
    text: 'Open to connecting with Dubai real estate teams and exploring opportunities where consultative sales experience and a customer-first approach can contribute.',
  },
};

export const nav: NavItem[] = [
  { id: 'about', label: 'About' },
  { id: 'experience', label: 'Experience' },
  { id: 'strengths', label: 'Strengths' },
  { id: 'direction', label: 'Career Direction' },
  { id: 'contact', label: 'Contact' },
];
