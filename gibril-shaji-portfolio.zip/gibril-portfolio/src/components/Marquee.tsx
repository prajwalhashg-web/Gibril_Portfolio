import { candidate } from '../data/candidate';

/** The one loud moment: the tagline travels edge to edge. Paused on hover, static under reduced motion. */
export function Marquee() {
  const line = candidate.hero.tagline;
  return (
    <div className="marquee" role="region" aria-label="Tagline">
      <p className="sr-only">{line}</p>
      <div className="marquee__track" aria-hidden="true">
        {[0, 1].map((n) => (
          <span className="marquee__item" key={n}>
            {line}
            <span className="marquee__mark" />
          </span>
        ))}
      </div>
    </div>
  );
}
