import { candidate } from '../data/candidate';

/** The languages run as one line of poster-scale type, opened by the heading itself. */
export function LanguagesSection() {
  const langs = candidate.languages;
  return (
    <section className="langs" id="languages" aria-labelledby="langs-title">
      <div className="wrap">
        <div className="langs__line" data-reveal>
          <h2 id="langs-title" className="langs__lead">Languages:</h2>{' '}
          <span className="langs__names">
            {langs.map((l, i) => (
              <span key={l}>
                <span className="langs__name">{l}</span>
                {i < langs.length - 1 ? ', ' : '.'}
              </span>
            ))}
          </span>
        </div>
        <p className="langs__note" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
          Four languages, as listed in his CV.
        </p>
      </div>
    </section>
  );
}
