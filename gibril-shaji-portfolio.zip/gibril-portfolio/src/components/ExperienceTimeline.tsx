import { candidate } from '../data/candidate';

export function ExperienceTimeline() {
  return (
    <section className="experience section" id="experience" aria-labelledby="experience-title">
      <div className="wrap">
        <div className="experience__head grid12">
          <h2 id="experience-title" data-reveal>Professional Experience</h2>
          <p className="experience__intro" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
            Four roles across Dubai and India, from IT support to consultative technical sales. Most recent first.
          </p>
        </div>

        <ol className="roles">
          {candidate.roles.map((r, i) => (
            <li className={`role${r.end === 'Present' ? ' role--current' : ''}`} key={r.company} data-reveal style={{ '--i': i % 2 } as React.CSSProperties}>
              <p className="role__dates">
                <time>{r.start}</time> to <time>{r.end}</time>
              </p>
              <div className="role__who">
                <h3>{r.title}</h3>
                <p className="role__co">{r.company}</p>
                <p className="role__loc">{r.location}</p>
              </div>
              <ul className="role__points">
                {r.points.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
