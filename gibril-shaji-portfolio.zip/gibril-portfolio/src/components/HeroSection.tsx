import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { candidate } from '../data/candidate';
import { FitName } from './FitName';
import { ResumeDownload } from './ResumeDownload';

export function HeroSection() {
  const [first, last] = candidate.name.toUpperCase().split(' ');
  return (
    <section className="hero" id="top" aria-labelledby="hero-name">
      <div className="wrap">
        <h1 id="hero-name" className="hero__name">
          <span className="sr-only">{candidate.name}, {candidate.headline}</span>
          {/* One fitted line on wide screens, two stacked lines on phones */}
          <FitName className="hero__name-line hero__name-line--wide" text={candidate.name.toUpperCase()} />
          <FitName className="hero__name-line hero__name-line--stack" text={first} />
          <FitName className="hero__name-line hero__name-line--stack" text={last} />
        </h1>

        <div className="hero__grid">
          <div className="hero__stage">
            <p className="hero__statement">{candidate.hero.statement}</p>
            <p className="hero__support">{candidate.hero.support}</p>
            <div className="hero__actions">
              <a className="btn btn--light" href="#experience">
                <span>Explore My Experience</span>
                <ArrowRight aria-hidden="true" />
              </a>
              <a className="text-link text-link--on-dark" href={candidate.linkedin} target="_blank" rel="noopener noreferrer">
                Connect on LinkedIn
                <ArrowUpRight aria-hidden="true" />
                <span className="sr-only">(opens in a new tab)</span>
              </a>
            </div>
          </div>

          <ul className="hero__rail" aria-label="At a glance">
            {candidate.facts.map((f) => (
              <li className="hero__fact" key={f}>{f}</li>
            ))}
            <li className="hero__fact hero__fact--action">
              <ResumeDownload className="hero__resume" label="Download Resume" />
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
