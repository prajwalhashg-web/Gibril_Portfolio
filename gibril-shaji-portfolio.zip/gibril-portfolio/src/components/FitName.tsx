import { useLayoutEffect, useRef, useState } from 'react';

type Props = { text: string; className?: string };

/**
 * Sets a word as display type fitted exactly to its container width.
 * Uses an SVG whose viewBox is measured from the rendered glyphs, so the
 * word runs margin to margin at any width without wrapping or distortion.
 * Decorative: the accessible name is provided by the parent heading.
 */
export function FitName({ text, className }: Props) {
  const textRef = useRef<SVGTextElement>(null);
  // Reasonable estimate for Poppins Bold caps until the font has loaded.
  const [box, setBox] = useState({ x: 0, y: -71, w: text.length * 70, h: 72 });

  useLayoutEffect(() => {
    let cancelled = false;
    const measure = () => {
      const el = textRef.current;
      if (!el || cancelled) return;
      const b = el.getBBox();
      if (b.width > 0) {
        // Trim to the cap height: Poppins caps sit between baseline and ~0.70em.
        setBox({ x: b.x, y: -70.5, w: b.width, h: 70.5 });
      }
    };
    measure();
    if (document.fonts?.ready) document.fonts.ready.then(measure);
    return () => {
      cancelled = true;
    };
  }, [text]);

  return (
    <svg
      className={className}
      viewBox={`${box.x} ${box.y} ${box.w} ${box.h}`}
      preserveAspectRatio="xMinYMax meet"
      aria-hidden="true"
      focusable="false"
    >
      <text ref={textRef} x="0" y="0" fontSize="100" fontWeight="700" fill="currentColor" letterSpacing="-4">
        {text}
      </text>
    </svg>
  );
}
