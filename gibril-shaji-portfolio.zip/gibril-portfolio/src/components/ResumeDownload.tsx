import { Download } from 'lucide-react';
import { candidate } from '../data/candidate';

type Props = { className?: string; label?: string };

/** Downloads the real resume PDF served from /public/resume. */
export function ResumeDownload({ className = 'btn btn--resume', label = 'Download Resume' }: Props) {
  return (
    <a
      className={className}
      href={candidate.resume.href}
      download={candidate.resume.fileName}
      type="application/pdf"
    >
      <span>{label}</span>
      <Download aria-hidden="true" />
      <span className="sr-only">(PDF)</span>
    </a>
  );
}
