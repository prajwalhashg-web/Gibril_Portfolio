import { FileText, Funnel, Handshake, MessagesSquare, Presentation, Wrench } from 'lucide-react';
import type { Strength } from '../data/candidate';
import { candidate } from '../data/candidate';

const icons: Record<Strength['icon'], typeof Handshake> = {
  consult: Handshake,
  qualify: Funnel,
  present: Presentation,
  docs: FileText,
  communicate: MessagesSquare,
  solve: Wrench,
};

export function StrengthsGrid() {
  return (
    <section className="strengths section" id="strengths" aria-labelledby="strengths-title">
      <div className="wrap">
        <div className="strengths__head grid12">
          <h2 id="strengths-title" data-reveal>Transferable Sales Strengths</h2>
          <p className="strengths__intro" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
            Six strengths, each drawn from documented sales and support work.
          </p>
        </div>

        <ul className="cards">
          {candidate.strengths.map((s, i) => {
            const Icon = icons[s.icon];
            return (
              <li className={`card card--${i + 1}`} key={s.title} data-reveal style={{ '--i': i % 3 } as React.CSSProperties}>
                <h3>
                  <Icon aria-hidden="true" />
                  {s.title}
                </h3>
                <p>{s.text}</p>
              </li>
            );
          })}
        </ul>

        {/* TABLE 1 */}
        <div className="tablock" aria-labelledby="value-title">
          <div className="tablock__head" data-reveal>
            <h3 id="value-title" className="tablock__title">What I Bring to a Real Estate Sales Team</h3>
            <p className="tablock__support">
              My experience in consultative technical sales has taught me to understand customer requirements, explain options
              clearly, and support informed purchase decisions.
            </p>
          </div>
          <div className="tbl tbl--stack" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
            <table className="t-value">
              <caption className="sr-only">Core strengths, the experience behind each, and how each could apply in real estate</caption>
              <colgroup>
                <col className="c-a" />
                <col className="c-b" />
                <col className="c-c" />
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">Core strength</th>
                  <th scope="col">Evidence from my experience</th>
                  <th scope="col">
                    Potential value in real estate
                    <span className="th-note">Transferable application, not past property work</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {candidate.value.map((r) => (
                  <tr key={r.strength}>
                    <th scope="row" data-label="Core strength">{r.strength}</th>
                    <td data-label="Evidence from my experience">{r.evidence}</td>
                    <td className="is-future" data-label="Potential value in real estate">{r.potential}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
