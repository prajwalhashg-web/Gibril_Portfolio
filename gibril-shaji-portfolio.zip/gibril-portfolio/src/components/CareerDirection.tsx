import { useState } from 'react';
import { candidate } from '../data/candidate';

/**
 * TABLE 4 with the page's one live thing: a recruiter picks the kind of team
 * they hire for and sees how Gibril intends to contribute there. Without
 * script, the full table is still there and readable.
 */
export function CareerDirection() {
  const [selected, setSelected] = useState(candidate.areas[0].id);
  const current = candidate.areas.find((a) => a.id === selected) ?? candidate.areas[0];

  return (
    <section className="direction section" id="direction" aria-labelledby="direction-title">
      <div className="wrap grid12">
        <div className="direction__intro">
          <h2 id="direction-title" data-reveal>Where I Aim to Create Value</h2>
          <p className="direction__label" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
            Career interests, not existing specialisations or proven results.
          </p>

          <div className="picker" data-reveal style={{ '--i': 2 } as React.CSSProperties}>
            <p className="picker__q" id="picker-q">Which team are you hiring for?</p>
            <div className="picker__options" role="group" aria-labelledby="picker-q">
              {candidate.areas.map((a) => (
                <button
                  key={a.id}
                  type="button"
                  className="picker__btn"
                  aria-pressed={a.id === selected}
                  aria-controls="picker-answer"
                  onClick={() => setSelected(a.id)}
                >
                  {a.area}
                </button>
              ))}
            </div>
            <div className="picker__answer" id="picker-answer" aria-live="polite">
              <p className="picker__area">{current.area}</p>
              <p className="picker__focus">{current.focus}</p>
              <p className="picker__strength">
                <span>Strength he would bring</span>
                {current.strength}
              </p>
            </div>
          </div>
        </div>

        <div className="direction__table" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
          <h3 className="tablock__title" id="areas-title">Where I aim to apply my sales experience</h3>
          <div className="tbl tbl--stack">
            <table className="t-areas" aria-labelledby="areas-title">
              <colgroup>
                <col className="c-a" />
                <col className="c-b" />
                <col className="c-c" />
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">
                    Target area
                    <span className="th-note">Area of interest</span>
                  </th>
                  <th scope="col">Relevant transferable strength</th>
                  <th scope="col">Intended contribution</th>
                </tr>
              </thead>
              <tbody>
                {candidate.areas.map((a) => (
                  <tr key={a.id} className={a.id === selected ? 'is-selected' : undefined}>
                    <th scope="row" data-label="Target area (interest)">{a.area}</th>
                    <td data-label="Relevant transferable strength">{a.strength}</td>
                    <td className="is-future" data-label="Intended contribution">{a.contribution}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
