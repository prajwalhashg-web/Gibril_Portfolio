import { candidate } from '../data/candidate';

export function QualificationsSection() {
  return (
    <section className="quals section" id="qualifications" aria-labelledby="quals-title">
      <div className="wrap grid12">
        <div className="quals__head">
          <h2 id="quals-title" data-reveal>Education and Professional Toolkit</h2>
        </div>

        <div className="quals__lists" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
          <div className="quals__group">
            <h3>Education</h3>
            <p>{candidate.education}</p>
          </div>
          <div className="quals__group">
            <h3>Certifications</h3>
            <ul>
              {candidate.certifications.map((c) => (
                <li key={c.name}>
                  {c.name}
                  {c.issuer && <span>, {c.issuer}</span>}
                </li>
              ))}
            </ul>
          </div>
          <div className="quals__group">
            <h3>Tools</h3>
            <p>{candidate.tools.join(', ')}</p>
          </div>
        </div>

        {/* TABLE 3 */}
        <div className="quals__skills" data-reveal style={{ '--i': 2 } as React.CSSProperties}>
          <h3 className="tablock__title" id="skills-title">Skills I Can Bring to the Role</h3>
          <div className="tbl tbl--stack">
            <table className="t-skills" aria-labelledby="skills-title">
              <colgroup>
                <col className="c-a" />
                <col className="c-b" />
              </colgroup>
              <thead>
                <tr>
                  <th scope="col">Verified skill</th>
                  <th scope="col">Relevance to a real estate sales role</th>
                </tr>
              </thead>
              <tbody>
                {candidate.skills.map((s) => (
                  <tr key={s.skill}>
                    <th scope="row" data-label="Verified skill">{s.skill}</th>
                    <td data-label="Relevance to a real estate sales role">{s.relevance}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
