import { candidate } from '../data/candidate';

export function ProfessionalIntro() {
  const { intro, portrait } = candidate;
  return (
    <section className="intro section" id="about" aria-labelledby="about-title">
      <div className="wrap grid12">
        <aside className="intro__facts" aria-label="At a glance" data-reveal>
          <p><span>Location</span>{candidate.locationShort}</p>
          <p><span>In sales roles since</span>2022</p>
          <p><span>Reach</span><a href={`mailto:${candidate.email}`}>{candidate.email}</a></p>
        </aside>

        <div className="intro__body">
          <h2 id="about-title" data-reveal>{intro.heading}</h2>
          <p className="intro__lead" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
            {portrait ? (
              <img className="intro__cap" src={portrait.src} alt={portrait.alt} width="160" height="160" loading="lazy" />
            ) : (
              <span className="intro__cap intro__cap--mark" aria-hidden="true">GS</span>
            )}
            <strong>{candidate.name}</strong>{intro.lead.replace(candidate.name, '')}
          </p>
          <p className="intro__more" data-reveal style={{ '--i': 2 } as React.CSSProperties}>{intro.body}</p>

          <div className="intro__approach" data-reveal style={{ '--i': 3 } as React.CSSProperties}>
            <h3>How he works with customers</h3>
            <ul>
              {intro.approach.map((a) => (
                <li key={a}>{a}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
