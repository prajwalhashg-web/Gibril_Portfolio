import { ArrowUpRight } from 'lucide-react';
import { candidate, nav } from '../data/candidate';
import { FitName } from './FitName';

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="footer" aria-label="Site footer">
      <div className="wrap">
        <div className="footer__cols">
          <div>
            <p className="footer__strong">{candidate.name}</p>
            <p>{candidate.locationShort}</p>
          </div>
          <nav aria-label="Footer">
            <p className="footer__strong">On this page</p>
            <ul>
              {nav.map((n) => (
                <li key={n.id}><a href={`#${n.id}`}>{n.label}</a></li>
              ))}
            </ul>
          </nav>
          <div>
            <p className="footer__strong">Connect</p>
            <ul>
              <li>
                <a href={candidate.linkedin} target="_blank" rel="noopener noreferrer">
                  LinkedIn <ArrowUpRight aria-hidden="true" />
                  <span className="sr-only">(opens in a new tab)</span>
                </a>
              </li>
              <li><a href={`mailto:${candidate.email}`}>{candidate.email}</a></li>
            </ul>
          </div>
        </div>
        <div className="footer__word">
          <FitName text={candidate.name.toUpperCase()} />
        </div>
        <p className="footer__legal">© {year} {candidate.name}. All rights reserved.</p>
      </div>
    </footer>
  );
}
