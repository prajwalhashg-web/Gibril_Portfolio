import { useState } from 'react';
import { ArrowUpRight, Check, Copy, Phone } from 'lucide-react';
import { candidate } from '../data/candidate';
import { ResumeDownload } from './ResumeDownload';

function CopyButton({ value, label }: { value: string; label: string }) {
  const [done, setDone] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setDone(true);
      window.setTimeout(() => setDone(false), 1800);
    } catch {
      setDone(false);
    }
  };
  return (
    <button type="button" className="copy" onClick={copy} aria-label={`Copy ${label}`}>
      {done ? <Check aria-hidden="true" /> : <Copy aria-hidden="true" />}
      <span aria-live="polite">{done ? 'Copied' : 'Copy'}</span>
    </button>
  );
}

export function ContactSection() {
  const [user, domain] = candidate.email.split('@');
  return (
    <section className="contact" id="contact" aria-labelledby="contact-title">
      <div className="wrap contact__inner">
        <div className="contact__top">
          <h2 id="contact-title" data-reveal>{candidate.contact.heading}</h2>
          <p data-reveal style={{ '--i': 1 } as React.CSSProperties}>{candidate.contact.text}</p>
        </div>

        <div className="contact__mail" data-reveal style={{ '--i': 2 } as React.CSSProperties}>
          <a className="contact__email" href={`mailto:${candidate.email}`}>
            <span className="sr-only">Email </span>
            <span>{user}</span>
            <span className="contact__at">@{domain}</span>
          </a>
          <CopyButton value={candidate.email} label="email address" />
        </div>

        <div className="contact__bottom" data-reveal style={{ '--i': 3 } as React.CSSProperties}>
          <div className="contact__line">
            <a href={candidate.phoneHref} className="contact__link">
              <Phone aria-hidden="true" />
              <span className="sr-only">Phone </span>
              {candidate.phone}
            </a>
            <CopyButton value={candidate.phone} label="phone number" />
          </div>
          <a className="contact__link" href={candidate.linkedin} target="_blank" rel="noopener noreferrer">
            LinkedIn
            <ArrowUpRight aria-hidden="true" />
            <span className="sr-only">(opens in a new tab)</span>
          </a>
          <p className="contact__city">{candidate.locationShort}</p>
          <ResumeDownload />
        </div>
      </div>
    </section>
  );
}
