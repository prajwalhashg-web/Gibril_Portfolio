import { candidate } from '../data/candidate';

/** TABLE 2: reads left to right, from past experience to client benefit. */
export function TransferableSkills() {
  return (
    <section className="transfer section" id="transfer" aria-labelledby="transfer-title">
      <div className="wrap">
        <div className="transfer__head grid12">
          <h2 id="transfer-title" data-reveal>Experience That Transfers to Property Sales</h2>
          <div className="transfer__copy" data-reveal style={{ '--i': 1 } as React.CSSProperties}>
            <p className="lead-text">
              Different industries. Similar fundamentals: understanding people, communicating value, and supporting the customer
              journey.
            </p>
            <p className="transfer__note">
              These are transferable capabilities. They are not a record of past property transactions.
            </p>
          </div>
        </div>

        <div
          className="tbl tbl--stack tbl--flow"
          data-reveal
          style={{ '--i': 2 } as React.CSSProperties}
        >
          <table className="t-flow">
            <caption className="sr-only">How each part of my previous experience could apply in real estate, and what it offers the client</caption>
            <colgroup>
              <col className="c-a" />
              <col className="c-b" />
              <col className="c-c" />
              <col className="c-d" />
            </colgroup>
            <thead>
              <tr className="t-flow__groups">
                <th scope="colgroup" colSpan={2}>Experience I bring</th>
                <th scope="colgroup" colSpan={2}>How it can apply to real estate</th>
              </tr>
              <tr>
                <th scope="col">Previous experience</th>
                <th scope="col">What it demonstrates</th>
                <th scope="col">Real estate application</th>
                <th scope="col" className="is-benefit">Client benefit</th>
              </tr>
            </thead>
            <tbody>
              {candidate.transfer.map((r) => (
                <tr key={r.experience}>
                  <th scope="row" className="is-step" data-label="Previous experience">{r.experience}</th>
                  <td className="is-step" data-label="What it demonstrates">{r.demonstrates}</td>
                  <td className="is-step" data-label="Real estate application">{r.application}</td>
                  <td className="is-benefit" data-label="Client benefit">{r.benefit}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
